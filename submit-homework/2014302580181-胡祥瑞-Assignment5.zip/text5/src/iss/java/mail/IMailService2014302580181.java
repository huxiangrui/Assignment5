package iss.java.mail;

import javax.mail.MessagingException;
import java.io.IOException;

public interface IMailService2014302580181 {
    /**
     * @throws MessagingException 
     */
    public void connect() throws MessagingException;

    /**
     * @param recipient 
     * @param subject
     * @param content 
     * @throws MessagingException 
     */
    public void send(String recipient, String subject, Object content) throws MessagingException;

    /**
     * @return
     * @throws MessagingException 
     */
    public boolean listen() throws MessagingException;
    
    /**
     * @param sender 
     * @param subject 
     * @return 
     * @throws MessagingException 
     * @throws IOException
     */
    public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException;
}
