package iss.java.mail;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

import javax.mail.*;
import javax.mail.internet.MimeMessage;

public class IMailReceiver2014302580181 {
	public String pop3Server ;  
    public String protocal  ;
    private Session session;
    private Properties properties;
    private String username;
    private String password; 
    private Store store;
    private Folder folder;
    private Message [] messages;
    private boolean validate = true;
    public Properties getProperties(){
         properties = new Properties();
         properties.put("mail.pop3.host", this.pop3Server);
         properties.put("mail.pop3.auth", validate ? "true" : "false");
         return properties;
    } 
    public String getProtocal() {
        return protocal;
    }

    public void setProtocal(String protocal) {
        this.protocal = protocal;
    }   
    // 使用Properties对象获得Session对象  
    public void setDebug(){
        session = Session.getInstance(properties);  
        session.setDebug(true);  
    }
    // 利用Session对象获得Store对象，并连接pop3服务器  
    public Store getStore() throws MessagingException{ 
        Store store = session.getStore();  
        store.connect(pop3Server, username, password);
        return store;
    }
    // 获得邮箱内的邮件夹Folder对象，以"只读"打开  
    public Folder getFolder() throws MessagingException{
        Folder folder = store.getFolder("inbox");  
        folder.open(Folder.READ_ONLY);
        return folder;
    }
    // 获得邮件夹Folder内的所有邮件Message对象  
    public Message [] getMessages() throws MessagingException{
    Message [] messages = folder.getMessages();
    return messages;
    }
    public void setNamePass(String name, String pass) {
  	   username = name;
  	   password = pass;
     }  
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserName() {
        return username;
    }

    public void setUserName(String username) {
        this.username = username;
    }

    public boolean isValidate() {
        return validate;
    }

    public void setValidate(boolean validate) {
        this.validate = validate;
    } 
    public void Receiver(){
    int mailCounts = messages.length;  
    for(int i = 0; i < mailCounts; i++) {
    	try {
    		String subject = messages[i].getSubject();
    		String from = (messages[i].getFrom()[0]).toString();
    		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    		String input = br.readLine(); 
    		if("yes".equalsIgnoreCase(input)) {
    			messages[i].writeTo(System.out);
    			}
    		folder.close(false);
    		store.close();  

			} catch (IOException | MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}  
   
    }
 
}
