package iss.java.mail;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
public class IMailSender2014302580181 {
	   private MimeMessage mimeMsg;
       private Session session;
       private Properties properties;
       private Multipart multipart;
       private String username;
       private String password;
       public IMailSender2014302580181(String smtp) {
    	   setSmtpHost(smtp);
    	   createMimeMessage();
       }
       public void setSmtpHost(String hostName) {
    	   properties.put("mail.smtp.host", hostName);
    	   properties = System.getProperties();
       }
       public void createMimeMessage() {
    	   session = Session.getDefaultInstance(properties, null);
    	   mimeMsg = new MimeMessage(session);
    	   multipart = new MimeMultipart();
       }
       
       public void setNamePass(String name, String pass) {
    	   username = name;
    	   password = pass;
       }
       public String setSubject(String mailSubject) {
    	   try {
			mimeMsg.setSubject(mailSubject);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mailSubject;
    		
       }
       public String setBody(String Body) {
    	   BodyPart bp = new MimeBodyPart();
    	   try {
			bp.setContent("" + Body, "text/html;charset=utf-8");
			multipart.addBodyPart(bp);
			} 
    	   catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		return Body;
       }
       public String setExpenditer(String expenditer){
    	   try {
    		   mimeMsg.setFrom(new InternetAddress(expenditer));
    		   } catch (AddressException e) {
    			   // TODO Auto-generated catch block
    			   e.printStackTrace();
    			   } catch (MessagingException e) {
    				   // TODO Auto-generated catch block
    				   e.printStackTrace();
    		  }
    	   return expenditer; 
       }
       public String setRecipient(String recipient) {
    	   try {
			mimeMsg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient));
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return recipient;
    		
       }
       public void sendOut() {
    	   try {
    		   mimeMsg.setContent(multipart);
    		   mimeMsg.saveChanges();
    		   Session mailSession = Session.getInstance(properties, null);
    		   Transport transport = mailSession.getTransport("smtp");
    		   transport.connect((String) properties.get("mail.smtp.host"), username, password);
    		   transport.sendMessage(mimeMsg, mimeMsg.getRecipients(Message.RecipientType.TO));
    		   transport.close();
		   } 
    	   catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		   }
      }
      public static void mailsend(String smtp, String expenditer,String recipient,String mailSubject, String content, String username, String password){
    	  IMailSender2014302580181 theMail = new IMailSender2014302580181(smtp);
    	  theMail.setNamePass(username, password);
    	  theMail.setSubject(mailSubject);
    	  theMail.setExpenditer(expenditer);
    	  theMail.setRecipient(recipient);
    	  theMail.sendOut();
      }
}

