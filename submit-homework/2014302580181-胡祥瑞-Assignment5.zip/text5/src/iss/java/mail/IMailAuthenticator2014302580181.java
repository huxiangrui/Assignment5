package iss.java.mail;
import javax.mail.*;
public class IMailAuthenticator2014302580181 extends Authenticator{
	/**
     * 鐢ㄦ埛鍚嶏紙鐧诲綍閭锛�
     */
    private String username;
    /**
     * 瀵嗙爜
     */
    private String password;

    /**
     * 鍒濆鍖栭偖绠卞拰瀵嗙爜
     *
     * @param username 閭
     * @param password 瀵嗙爜
     */
    public IMailAuthenticator2014302580181(String username, String password) {
        this.username = username;
        this.password = password;
    }

    String getPassword() {
        return password;
    }

    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication(username, password);
    }

    String getUsername() {
        return username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
